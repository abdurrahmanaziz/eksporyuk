<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://sejoli.co.id
 * @since      1.0.0
 *
 * @package    Sejoli_Rest_Api
 * @subpackage Sejoli_Rest_Api/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Sejoli_Rest_Api
 * @subpackage Sejoli_Rest_Api/includes
 * @author     Sejoli Team <admin@sejoli.co.id>
 */
class Sejoli_Rest_Api_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
