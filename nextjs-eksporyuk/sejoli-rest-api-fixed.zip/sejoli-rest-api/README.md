# sejoli-rest-api
Provide REST-API data from Sejoli (Premium Membership Plugin).